---
title: "Pozvánka na shromáždění vlastníků jednotek"
language: cs
toc: false
md-style:
  style: svj-invitation
  annotations:
    - id: "ann-svj-01"
      createdAt: "2026-10-12T09:30:00Z"
      author: "K. Svoboda (Byt č. 3)"
      category: "question"
      text: "Proč máme hradit výměnu armatury my jako vlastníci, když se jedná o napojení na centrální otopnou soustavu domu?"
      range:
        blockIndex: 12
        quote: "Byt č. 3"
        prefixContext: "| "
        suffixContext: " | K. Svoboda |"
        textOffsetInBlock: 0
      resolved: false
    - id: "ann-svj-02"
      createdAt: "2026-10-12T14:15:00Z"
      author: "Jan Dvořák (Předseda výboru SVJ)"
      category: "insight"
      text: "Podle § 6 nařízení vlády č. 366/2013 Sb. jsou společnou částí pouze stoupací rozvody až po uzavírací armaturu. Samotné radiátorové kohouty a šroubení uvnitř bytu jsou ze zákona i Prohlášení vlastníka ve výlučném vlastnictví jednotky."
      range:
        blockIndex: 12
        quote: "V souladu s Prohlášením vlastníka"
        prefixContext: ""
        suffixContext: ""
        textOffsetInBlock: 0
      resolved: true
    - id: "ann-svj-03"
      createdAt: "2026-10-13T10:00:00Z"
      author: "Ing. Marie Černá (Místopředsedkyně výboru)"
      category: "feedback"
      text: "K navýšení příspěvku do fondu oprav na 26 Kč/m² je podle § 1206 NOZ zapotřebí nadpoloviční většina přítomných hlasů. Z předběžné prezence máme avizováno 68 % podlahové plochy."
      range:
        blockIndex: 14
        quote: "26 Kč / m² měsíčně"
        prefixContext: "ve výši **"
        suffixContext: "** s účinností"
        textOffsetInBlock: 0
      resolved: false
---

Společenství vlastníků jednotek domu Jabloňová 24, Praha  
se sídlem: Jabloňová 1420/24, 106 00 Praha 10 – Záběhlice  
IČO: 76543210  
Bankovní účet SVJ: 1420-76543210/0100 (Komerční banka, a.s.)

Výbor Společenství vlastníků jednotek domu Jabloňová 24 svolává v souladu se stanovami SVJ a příslušnými ustanoveními občanského zákoníku (§ 1205 a § 1207 NOZ) **řádné shromáždění vlastníků jednotek**.

## Termín a místo konání

* **Datum:** středa **21. října 2026**  
* **Čas:** prezence od 17:30 hod., zahájení v **18:00 hod.**  
* **Místo:** společenská místnost domu (suterén, vchod B)

## Program shromáždění

::: {#toc section="Detaily jednání"}
:::

**Za výbor SVJ Jabloňová 24, Praha**  
*(Jan Dvořák – předseda výboru, Ing. Marie Černá – místopředsedkyně, Tomáš Procházka – člen výboru)*

## Detaily jednání

Podklady pro jednotlivé body programu, návrhy smluvních ujednání, rozpočty a revizní zprávy jsou vlastníkům jednotek k dispozici na zabezpečeném cloudovém úložišti SVJ:

[Podklady pro shromáždění 2026 (odkaz na cloud)](https://svj-jablonova24.priklad.cz/podklady-2026)

V případě dotazů či připomínek k podkladům před konáním shromáždění se můžete obracet na výbor prostřednictvím e-mailu: [vybor@svj-jablonova24.priklad.cz](mailto:vybor@svj-jablonova24.priklad.cz).

1. ### Zahájení

Zahájení schůze, ověření usnášeníschopnosti shromáždění podle § 1206 NOZ, volba orgánů shromáždění (předsedající, zapisovatel, ověřovatel zápisu a sčitatel hlasů), schválení navrženého programu jednání.

2. ### Zpráva výboru o hospodaření a schválení účetní závěrky za rok 2025

Výbor předkládá shrnutí hospodaření společenství za uplynulý kalendářní rok. Celkové provozní náklady domu odpovídaly schválenému finančnímu plánu. Dlouhodobá záloha na opravy (fond oprav) vykazuje ke dni 31. 12. 2025 zůstatek 1 452 800 Kč. Řádná účetní závěrka byla zpracována správcovskou společností a ověřena revizorem bez výhrad.

***Návrh výboru:*** Shromáždění schvaluje řádnou účetní závěrku SVJ za rok 2025 a převod výsledku hospodaření do fondu oprav.

3. ### Zpráva o technickém stavu budovy a provedených opravách

V průběhu uplynulého období proběhlo několik důležitých technických zásahů a zákonných revizí:

* **Oprava hydroizolace:** Byla provedena sanace dilatačních spár a oprava hydroizolace světlíku nad sekcí A, čímž bylo odstraněno zatékání do společných chodeb.
* **Revize rozvodů plynu a spalinových cest:** Všechny bytové jednotky úspěšně prošly periodickou kontrolou těsnosti.
* **Servis výtahů:** Proběhla výměna nosných lan u výtahu ve vchodu B v rámci předepsané desetileté inspekce.

Děkujeme všem vlastníkům za součinnost a zpřístupnění jednotek během prováděných kontrol.

4. ### Rozúčtování nákladů instalace dálkových odečtů měřidel

V souladu s legislativními požadavky na měsíční informování o spotřebě tepla a vody podle § 8a zákona o službách č. 67/2013 Sb. byla dokončena instalace rádiových modulů na stávající poměrové měřiče tepla a vodoměry.

Během instalace se v některých jednotkách vyskytla nutnost výměny vadných či zatuhlých uzavíracích ventilů a připojovacích šroubení. V souladu s § 6 nařízení vlády č. 366/2013 Sb. a Prohlášením vlastníka jsou tyto armatury výlučným příslušenstvím jednotky a náklady na jejich výměnu hradí vlastník dané jednotky:

| Byt | Vlastník | Termoregulační ventil | Uzavírací kulový kohout | Vícepráce instalace (h) | Náklad bez DPH | Cena vč. DPH (12 %) |
| :--- | :--- | :---: | :---: | :---: | :---: | :---: |
| Byt č. 3 | K. Svoboda | 2 ks | 0 ks | 1,0 h | 1 650 Kč | 1 848 Kč |
| Byt č. 7 | M. Veselá | 0 ks | 2 ks | 1,5 h | 1 980 Kč | 2 218 Kč |
| Byt č. 12 | P. Urban | 3 ks | 1 ks | 2,0 h | 3 420 Kč | 3 830 Kč |
| Byt č. 18 | J. Richter | 1 ks | 1 ks | 1,0 h | 1 450 Kč | 1 624 Kč |
| Byt č. 22 | H. Blažková | 2 ks | 2 ks | 2,0 h | 2 890 Kč | 3 237 Kč |
| Byt č. 29 | T. Mareš | 4 ks | 0 ks | 2,5 h | 3 860 Kč | 4 323 Kč |

***Návrh výboru:*** Výbor navrhuje přeúčtovat uvedené přímé náklady jednotlivým vlastníkům formou jednorázové položky v předpisu záloh splatné do 30. 11. 2026. Platbu lze provést bankovním převodem na účet `1420-76543210/0100` pod variabilním symbolem odpovídajícím číslu bytu.

5. ### Úprava výše měsíčního příspěvku do fondu oprav

Současná výše příspěvku na správu domu a pozemku (fond oprav) činí 18 Kč/m² měsíčně a nebyla měněna od roku 2019. S ohledem na kumulovanou inflaci ve stavebnictví a nutnost vytvoření finanční rezervy pro plánovanou revitalizaci střechy v roce 2028 navrhuje výbor navýšení příspěvku podle § 1180 NOZ.

Podrobná kalkulace dopadů na jednotlivé dispozice bytů:

* **Dispozice 1+kk (cca 36 m²):** navýšení o cca 288 Kč / měsíc
* **Dispozice 2+kk (cca 54 m²):** navýšení o cca 432 Kč / měsíc
* **Dispozice 3+1 (cca 78 m²):** navýšení o cca 624 Kč / měsíc

***Návrh výboru:*** Shromáždění schvaluje podle § 1180 NOZ a stanov novou sazbu příspěvku do fondu oprav ve výši **26 Kč / m² měsíčně** s účinností od 1. ledna 2027.

6. ### Modernizace přístupového a kamerového systému

V návaznosti na předchozí podněty vlastníků ohledně zabezpečení suterénních prostor, sklepních kójí a koláren předkládá výbor návrh na přechod z mechanických klíčů na čipový systém (RFID) a instalaci 4 bezpečnostních kamer v prostorách vstupů:

| Dodavatel | Rozsah řešení | Doba montáže | Záruka | Celková cena bez DPH |
| :--- | :--- | :---: | :---: | :---: |
| **Securitas Domus s.r.o.** | 2× čtečka, 4× IP kamera 4K, NVR úložiště 30 dní | 14 dní | 60 měsíců | 148 500 Kč |
| **Alfa Bezpečnost s.r.o.** | 2× čtečka, 3× IP kamera Full HD, NVR úložiště 14 dní | 21 dní | 36 měsíců | 132 000 Kč |
| **SafeHouse Systems a.s.** | 2× čtečka, 4× IP kamera 4K, cloudové úložiště | 30 dní | 36 měsíců | 165 000 Kč |

Kamerový systém bude plně vyhovovat požadavkům na ochranu osobních údajů podle čl. 6 odst. 1 písm. f) GDPR s režimem záznamu v délce 14 dní bez živého přenosu.

***Návrh výboru:*** Pověření výboru k uzavření smlouvy o dílo s vybranou společností Securitas Domus s.r.o. v maximální výši 150 000 Kč bez DPH s financováním z fondu oprav.

7. ### Změna servisní smlouvy předávací stanice tepla

V souvislosti s ukončením platnosti stávající smlouvy na servis domovní výměníkové stanice tepla provedl výbor srovnání nabídky stávajícího dodavatele a městské teplárenské společnosti:

| Parametr služby (ceny bez DPH) | Dosavadní dodavatel (TermoServis) | Pražská teplárenská, a.s. |
| :--- | :--- | :--- |
| **Pravidelný roční paušál** | 24 000 Kč | 38 000 Kč (zahrnuto v sazbě) |
| **Garantovaný dojezd k havárii** | do 24 hodin | **do 2 hodin (nonstop dispečink)** |
| **Dálkový telemetrický dohled** | Pasivní (hlášení odběratelem) | **Aktivní automatický monitoring** |
| **Drobné opravy v ceně** | Ne (účtovány zvlášť) | Ano (materiál do 10 000 Kč ročně) |

***Návrh výboru:*** Doporučujeme uzavření nové smlouvy s Pražskou teplárenskou, a.s. z důvodu výrazně kratší dojezdové doby při havarijním výpadku vytápění v zimních měsících.

8. ### Schválení plánu revizí a údržby pro rok 2027

Výbor předkládá orientační harmonogram údržby pro následující kalendářní rok:

1. Pravidelná revize elektroinstalace společných prostor a hromosvodů (březen 2027)
2. Tlakové čištění a inspekce svislých odpadních svodů (květen 2027)
3. Nátěr vstupních portálů a repase zavíračů (červenec 2027)
4. Odborná prohlídka a bezpečnostní zkouška výtahu (říjen 2027)

Předpokládané čerpání rozpočtu údržby činí 180 000 Kč.

9. ### Zřízení internetových stránek a elektronické nástěnky SVJ

Za účelem zjednodušení komunikace, zveřejňování zápisů a hospodárného předávání informací navrhuje výbor zřízení domény a webového portálu SVJ s využitím specializovaného systému pro správu domů. Roční provozní náklad činí 4 200 Kč.

***Návrh výboru:*** Schválení zřízení oficiálního webu SVJ a vyhrazení finančních prostředků na roční licenci.

10. ### Různé a diskuse

Prostor pro podněty přítomných vlastníků, dotazy na výbor a diskusi k běžnému provozu bytového domu.

11. ### Závěr

Rekapitulace výsledků hlasování, schválení zápisu a oficiální ukončení shromáždění.

---

## Další informace pro vlastníky

* **Účast a plná moc:** Nemůžete-li se shromáždění zúčastnit osobně, využijte prosím možnost zplnomocnit jiného vlastníka či zástupce. Formulář plné moci je k dispozici na webových stránkách nebo u domovní nástěnky.
* **Podklady a nahlížení:** Všechny podkladové materiály jsou k nahlédnutí po předchozí dohodě s výborem.
* **Kontakt na výbor:** [vybor@svj-jablonova24.priklad.cz](mailto:vybor@svj-jablonova24.priklad.cz) | telefon: +420 777 000 111

**Za výbor SVJ Jabloňová 24, Praha**  
*(Jan Dvořák – předseda výboru, Ing. Marie Černá – místopředsedkyně, Tomáš Procházka – člen výboru)*
